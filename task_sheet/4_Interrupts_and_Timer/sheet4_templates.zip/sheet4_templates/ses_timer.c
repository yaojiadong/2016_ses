/* INCLUDES ******************************************************************/
#include "ses_timer.h"

/* DEFINES & MACROS **********************************************************/
#define TIMER1_CYC_FOR_5MILLISEC    //TODO
#define TIMER2_CYC_FOR_1MILLISEC	//TODO 


/*FUNCTION DEFINITION ********************************************************/
void timer2_setCallback(pTimerCallback cb) {
	// TODO
}

void timer2_start() {
	// TODO
}


void timer2_stop() {
    // TODO
}

void timer1_setCallback(pTimerCallback cb) {
	// TODO
}


void timer1_start() {
	// TODO
}


void timer1_stop() {
	// TODO
}

ISR(TIMER1_COMPA_vect) {
	// TODO
}

ISR(TIMER2_COMPA_vect) {
	// TODO
}
